def face(parent):
	parent.tabWidget.setCurrentIndex(1)
	parent.faceWidthX.setText('10')
	parent.faceDepthY.setText('5')
	parent.faceLeft.setText('0')
	parent.faceRear.setText('0')
	parent.faceTop.setText('0')
	parent.faceTool.setText('5')
	parent.faceToolDia.setText('1.0')
	parent.faceRPM.setText('1800')
	parent.faceFeed.setText('25')
	parent.faceStep.setText('25')
	parent.faceSafeZ.setText('0.75')
	parent.faceLeadIn.setText('.5')
	parent.faceCutDepth.setText('.5')
	parent.faceStepDepth.setText('.125')

	
